############# Develop machine learning algorithms for prediction of RUE, HI and phenology
Weather_ML_table_for_phen <- NULL
Weather_ML_table_for_HI <- NULL
Weather_ML_table_for_RUE <- NULL 
for (iml_treat in 1:length(Training_treat)){
  
  #### Select treatment and save total days from emergence to anthesis and maturity
  itreat_for_ML <- Training_treat[iml_treat]
  
  # Subset crop data for treatment 
  Crop_dates_treatment_ML <- subset(End_of_season_crop_data, End_of_season_crop_data$Treatment==itreat_for_ML)
  
  # Day of emergence of treatment
  DOE <- Crop_dates_treatment_ML$Emergence + Crop_dates_treatment_ML$Planting_year*1000
  
  # Emergence to anthesis and maturity total number of days
  Emerg_anth_treat_ML <- Crop_dates_treatment_ML$Emer_Anth_days
  Emerg_matur_treat_ML <- Crop_dates_treatment_ML$Emer_Matur_days
  
  # Import correct weather file per treatment 
  if (str_sub(itreat_for_ML,-1,-1)=='C'){
    Input_weather_file <- read.table('./Input_data/Weather_data/AZ000306.wth', header = T)
    
  }else if (str_sub(itreat_for_ML,-1,-1)=='H'){
    if (itreat_for_ML=='1H'){
      Input_weather_file <- read.table('./Input_data/Weather_data/AZ110306.wth', header = T)
    }else if (itreat_for_ML=='7H'){
      Input_weather_file <- read.table('./Input_data/Weather_data/AZ310306.wth', header = T)
    }else if (itreat_for_ML=='9H'){
      Input_weather_file <- read.table('./Input_data/Weather_data/AZ440306.wth', header = T)
    }else if (itreat_for_ML=='14H'){
      Input_weather_file <- read.table('./Input_data/Weather_data/AZ610306.wth', header = T)
    }
  }
  
  # Correct the date column and set it as integer
  Input_weather_file$X.DATE <-Input_weather_file$X.DATE + 2000000
  Input_weather_file$X.DATE <- as.integer(Input_weather_file$X.DATE)
  
  ### Subset weather variables to start at day of emergence of specific treatment
  Weather_file_treatment_ML <- subset(Input_weather_file, Input_weather_file$X.DATE >= DOE)
  
  # Add new column with day number starting with 1 on first day after emergence
  Weather_file_treatment_ML$Day <- seq(1:nrow(Weather_file_treatment_ML))
  
  # Subset weather file for 366 days after emergence (since wheat is annual crop)
  Weather_file_treatment_ML <- subset(Weather_file_treatment_ML, Weather_file_treatment_ML$Day <= 366)
  
  ####### Make table for prediction of phenology
  # Add phenology column with iphen = 0 if crop is in pre-anthesis stage; iphen = 1 for anthesis - maturity; iphen = 2 for post-maturity 
  for (jphenol in 1:nrow(Weather_file_treatment_ML)){
    if (Weather_file_treatment_ML$Day[jphenol] < Emerg_anth_treat_ML){
      Weather_file_treatment_ML$iphen[jphenol] <- 0
    }else if (Weather_file_treatment_ML$Day[jphenol] >= Emerg_anth_treat_ML & Weather_file_treatment_ML$Day[jphenol] < Emerg_matur_treat_ML){
      Weather_file_treatment_ML$iphen[jphenol] <- 1
    }else{
      Weather_file_treatment_ML$iphen[jphenol] <- 2
    }
  }

  # Calculate cumulative sum of SRAD
  Weather_file_treatment_ML$SRAD_ACCU <- cumsum(Weather_file_treatment_ML$SRAD)
  
  ### Calculate thermal time accumulation for treatment
  Tav <- (Weather_file_treatment_ML$TMAX + Weather_file_treatment_ML$TMIN)/2
  Weather_file_treatment_ML$TACCU <- cumsum(Tav)
  
    # Calculate VPD   
  saturation_vapor_pressure_leaf = (0.61078 * exp(17.27 * Weather_file_treatment_ML$TMAX/(Weather_file_treatment_ML$TMAX + 237.3)) + 
                                    0.61078 * exp(17.27 * Weather_file_treatment_ML$TMIN/(Weather_file_treatment_ML$TMIN + 237.3)))/2
  
  saturation_vapor_pressure_dew_point = 0.61078 * exp(17.27 * Weather_file_treatment_ML$TDEW/(Weather_file_treatment_ML$TDEW + 237.3))
  Weather_file_treatment_ML$VPD = saturation_vapor_pressure_leaf - saturation_vapor_pressure_dew_point
    
  # Subset weather file of given treatment only for days from emergence to maturity (for use prediction of RUE and dHI/dt)
  weather_treat_growing_seas_ML <- subset(Weather_file_treatment_ML, Weather_file_treatment_ML$Day <= Emerg_matur_treat_ML)
  
  # Subset weather file of given treatment with equal anthesis to maturity and post-maturity days (for use in prediction of iphen)
  weather_treat_growing_seas_ML_for_phen <- subset(Weather_file_treatment_ML, Weather_file_treatment_ML$Day <= 
                                            tail(which(Weather_file_treatment_ML$iphen==1), 1) + sum(Weather_file_treatment_ML$iphen == 1))
        
  ######## Build matrices with target variables (RUE, dHI/dt, iphen) and covariates 
  # Import optimal biomass and yield time series from s-curve fitting (script: Biomass_and_yield_s_curves.R)
  w_treat_train <- unlist(biom_yield_opt_list[[iml_treat]][1])*100
  yield_treat_train <- unlist(biom_yield_opt_list[[iml_treat]][2])*100
  
  ###### Calculate HI 
  HI_vec_train <- yield_treat_train/w_treat_train
  
  ##### Calculate RUE
  # Partition W to MP and MS
  MP_vec_train <- NULL
  MS_vec_train <- NULL
  MY_vec_train <- NULL
  RUE_vec_train <- NULL
  for (l in 1:length(w_treat_train)){
    BMASS_train = w_treat_train[l]
    HI_train = HI_vec_train[l]
    MP_train = as.numeric(newton.raphson(func_train, 0.1, 1000)[1])
    Qo_train = weather_treat_growing_seas_ML$SRAD[l]/2
    if (l==1){
      dW_train <- w_treat_train[l]
    }else{
      dW_train <- w_treat_train[l] - w_treat_train[l-1]
    }
    RUE_train <- dW_train/(Qo_train*(1-exp(-kfac*SLA*10^(-4)*MP_train)))
    RUE_vec_train <- c(RUE_vec_train, RUE_train)
    MS_train = h*(MP_train^g)
    MY_train = HI_train*BMASS_train
    
    # Update MP, SM, MY vectors
    MP_vec_train <- c(MP_vec_train, MP_train)
    MS_vec_train <- c(MS_vec_train, MS_train)
    MY_vec_train <- c(MY_vec_train, MY_train)
  }
  
  # Calculate MS_ratio, dHI/dt and MP_ratio_lag for use as features in ML algorithms 
  MS_ratio_train <- MS_vec_train / (MP_vec_train + MS_vec_train + MY_vec_train)
  dhdt_train <- c(0, diff(HI_vec_train))
  MP_ratio_train <- MP_vec_train / (MP_vec_train + MS_vec_train + MY_vec_train)
  MP_ratio_lag_train <- c(0, MP_ratio_train[1:length(MP_ratio_train) - 1])

  ###### Weather file for RUE prediction
  Weather_ML_table_for_RUE <- rbind(Weather_ML_table_for_RUE, data.frame(weather_treat_growing_seas_ML, RUE_vec_train, MP_ratio_lag_train, itreat_for_ML))
  
  ##### Weather file for HI prediction (data points start at anthesis i.e. iphen >0)
  weather_treat_post_anth_ML <- subset(weather_treat_growing_seas_ML, weather_treat_growing_seas_ML$iphen != 0)
  weather_treat_post_anth_ML$SRAD_ACCU <- cumsum(weather_treat_post_anth_ML$SRAD) 
  weather_treat_post_anth_ML$TAV <- (weather_treat_post_anth_ML$TMAX +  weather_treat_post_anth_ML$TMIN)/2
  weather_treat_post_anth_ML$TACCU <- cumsum(weather_treat_post_anth_ML$TAV)
  
  HI_vec_train_f <- HI_vec_train[HI_vec_train>0]
  HI_vec_train_lag_f <- c(0, 0, HI_vec_train_f[1:length(HI_vec_train_f) - 1])
  dhdt_train_for_ML <- c(0, dhdt_train[dhdt_train>0])
  Weather_ML_table_for_HI <- rbind(Weather_ML_table_for_HI, data.frame(weather_treat_post_anth_ML, HI_vec_train_lag_f, dhdt_train_for_ML, itreat_for_ML))   
  
  ##### Weather file for phenology prediction
  MS_ratio_train_f <- c(MS_ratio_train, rep(tail(MS_ratio_train, 1), (nrow(weather_treat_growing_seas_ML_for_phen) - length(MS_ratio_train))))
  Weather_ML_table_for_phen <- rbind(Weather_ML_table_for_phen, data.frame(weather_treat_growing_seas_ML_for_phen, MS_ratio_train_f, itreat_for_ML))
  
}
# Rename columns
names(Weather_ML_table_for_phen)[names(Weather_ML_table_for_phen) == 'MS_ratio_train_f'] <- 'MS_ratio'

names(Weather_ML_table_for_RUE)[names(Weather_ML_table_for_RUE) == 'RUE_vec_train'] <- 'RUE'
names(Weather_ML_table_for_RUE)[names(Weather_ML_table_for_RUE) == 'MP_ratio_lag_train'] <- 'MP_ratio_lag'


names(Weather_ML_table_for_HI)[names(Weather_ML_table_for_HI) == 'HI_vec_train_lag_f'] <- 'HI_lag'
names(Weather_ML_table_for_HI)[names(Weather_ML_table_for_HI) == 'dhdt_train_for_ML'] <- 'dhdt'

############# Apply ML algorithms for prediction of RUE, dHI/dt and iphen
xgb_best_hyperparams_table <- rf_best_hyperparams_table <- NULL

####### ML for phenology prediction
Weather_ML_table_for_phen_f <- Weather_ML_table_for_phen[, c('SRAD', 'TMIN', 'TMAX', 'SRAD_ACCU', 'TACCU', 'MS_ratio', 'iphen')]
Weather_ML_table_for_phen_f$iphen <- as.factor(Weather_ML_table_for_phen_f$iphen)

# Optimize ML phenology model
algor_for_opt <- 'Phenology'

if (ML_model == 'Random_forests'){
    # Optimize RF hyperparameters for phenology prediction
    source("./Optimize_ML_model_hyperparameters.R")
    ML_phen <- rand_forest(trees = rf_trees, mtry = rf_mtry, min_n = rf_min_n) %>%
               set_engine("ranger", importance = "impurity") %>%
               set_mode("classification") %>%
               fit(iphen ~., data = Weather_ML_table_for_phen_f)
    #ranger_obj_phen <- ML_phen$fit
    #ranger_obj_phen$variable.importance
  
}else if (ML_model == 'XG_boost') {
    source("./Optimize_ML_model_hyperparameters.R")
    ML_phen <- boost_tree(trees = xgb_trees, mtry = xgb_mtry, tree_depth = xgb_tree_depth) %>% 
    set_mode("classification") %>% 
    set_engine("xgboost")%>%
    fit(iphen ~., data = Weather_ML_table_for_phen_f)
}

############ ML for RUE prediction
Weather_ML_table_for_RUE_f <- Weather_ML_table_for_RUE[, c('SRAD', 'TMIN', 'TMAX', 'VPD', 'MP_ratio_lag', 'RUE')]

# Optimize ML RUE model
algor_for_opt <- 'RUE'

if (ML_model == 'Random_forests'){
  # Optimize RF hyperparameters for RUE prediction
    source("./Optimize_ML_model_hyperparameters.R")
    ML_rue <- rand_forest(trees = rf_trees, mtry = rf_mtry, min_n = rf_min_n) %>%
    set_engine("ranger", importance = "impurity") %>%
    set_mode("regression") %>%
    fit(RUE ~., data = Weather_ML_table_for_RUE_f)
    #ranger_obj_rue <- ML_rue$fit
    #ranger_obj_rue$variable.importance
    
}else if (ML_model == 'XG_boost') {
    source("./Optimize_ML_model_hyperparameters.R")
    ML_rue <- boost_tree(trees = xgb_trees, mtry = xgb_mtry, tree_depth = xgb_tree_depth) %>% 
    set_mode("regression") %>% 
    set_engine("xgboost")%>%
    fit(RUE ~., data = Weather_ML_table_for_RUE_f)
}

############# ML for HI prediction
Weather_ML_table_for_HI_f <- Weather_ML_table_for_HI[, c('SRAD', 'TMIN', 'TMAX', 'HI_lag', 'dhdt')]

# Optimize ML dHI/dt model
algor_for_opt <- 'dhdt'

if (ML_model == 'Random_forests'){
    # Optimize RF hyperparameters for dHI/dt prediction
    source("./Optimize_ML_model_hyperparameters.R")
    ML_dhdt <- rand_forest(trees = rf_trees, mtry = rf_mtry, min_n = rf_min_n) %>%
    set_engine("ranger", importance = "impurity") %>%
    set_mode("regression") %>%
    fit(dhdt ~., data = Weather_ML_table_for_HI_f)
    #ranger_obj_dhdt <- ML_dhdt$fit
    #ranger_obj_dhdt$variable.importance*100
    
}else if (ML_model == 'XG_boost') {
    source("./Optimize_ML_model_hyperparameters.R")
    ML_dhdt <- boost_tree(trees = xgb_trees, mtry = xgb_mtry, tree_depth = xgb_tree_depth) %>%  
    set_mode("regression") %>% 
    set_engine("xgboost")%>%
    fit(dhdt ~., data = Weather_ML_table_for_HI_f)
}


