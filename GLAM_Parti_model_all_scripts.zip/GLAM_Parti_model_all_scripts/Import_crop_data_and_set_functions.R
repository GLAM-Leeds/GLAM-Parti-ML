#### Packages to run GLAM-Parti
library(gridExtra)
library(ggpubr)
library(pracma) 
library(ggplot2) 
library(randomForest)
library(dplyr)
library(hydroGOF)
library(stringr)
library(ggpmisc)
library(xgboost) 
library(numDeriv)
library(tdr)
library(reshape2)
library(tidymodels)
library(ranger)
library(grid)
library(xtable)
library(doParallel)

##### Load crop data
End_of_season_crop_data <- read.csv('./Input_data/Crop_data/End_of_season_crop_data.csv')
End_of_season_crop_data$HI <- End_of_season_crop_data$max_yield/End_of_season_crop_data$max_biom
Within_season_crop_data <- read.csv('./Input_data/Crop_data/Within_season_crop_data.csv')

# Vector with all treatments of the 'Hot serial cereal experiment'
All_treat <- c('1C', '1H', '2C', '7C', '7H', '8C', '9C', '9H', '10C', '14C', '14H', '15C')

##### Set functions for use by the model
# Newton - Raphson method
newton.raphson <- function(f, a, b, tol = 10^(-2), n = 1000) {
  
  x0 <- a # Set start value to supplied lower bound
  k <- n # Initialize for iteration results
  
  # Check the upper and lower bounds to see if approximations result in 0
  fa <- f(a)
  if (fa == 0.0) {
    return(a)
  }
  
  fb <- f(b)
  if (fb == 0.0) {
    return(b)
  }
  
  for (i in 1:n) {
    dx <- genD(func = f, x = x0)$D[1] # First-order derivative f'(x0)
    x1 <- x0 - (f(x0) / dx) # Calculate next value x1
    k[i] <- x1 # Store x1
    # Once the difference between x0 and x1 becomes sufficiently small, output the results.
    if (abs(x1 - x0) < tol) {
      root.approx <- tail(k, n=1)
      res <- list('root approximation' = root.approx, 'iterations' = k)
      return(res)
    }
    # If Newton-Raphson has not yet reached convergence set x1 as x0 and continue
    x0 <- x1
  }
  print('Too many iterations in method')
}

# RMSE
RMSE = function(m, o){
  sqrt(mean((m - o)^2, na.rm = TRUE))
}

# SEMAC function to calculate MP during ML training period
func_train <- function(MP_train) {
  (1/(1-HI_train))*(MP_train + h*(MP_train^g)) - BMASS_train
}

# SEMAC function to calculate MP during model testing period
func_test <- function(MP) {
  (1/(1-HI))*(MP + h*(MP^g)) - RUE*Qo*(1-exp(-kfac*SLA*10^(-4)*MP)) - W
}







