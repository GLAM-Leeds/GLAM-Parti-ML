###### Evaluate GLAM-Parti with 50% of data used for ML training (i.e. six experiments) and 50% for model testing (i.e. six remaining treatments)
#### First train RF on 50% of data (6 experiments) and then run GLAM-Parti and evaluate the model skill

# Set working directory
setwd('Desktop/GLAM_Parti_model_all_scripts/')

set.seed(5)

Daily_model_output <- NULL
End_of_season_model_output <- NULL
  
# Call script to import crop data and set all functions (Newton-Raphson, SEMAC, etc)
source("./Import_crop_data_and_set_functions.R")

#Choose number of experiments and ML model in training period
no_experiments_training <- 6
irep <- 1
ML_model <- 'Random_forests'

# Sample treatments to be used for ML training  
Training_treat <- sample(All_treat, no_experiments_training)

# The rest treatments are used for model testing  
Eval_treat <- setdiff(All_treat, Training_treat)

# Call script to set model parameter values (g, h, SLA and kc)
source("./Model_parameters.R")

# Call script to find optimal biomass and yield time series for each treatment in training period based on observed data (we use s-curve formula of Yin et al. 2003)
source("./Biomass_and_yield_s_curves.R")

# Call script to train three RF alogrithms on the prediction of RUE, HI and Phenology
source("./Machine_learning_for_RUE_HI_and_Phenology.R")
  
# Call script to run GLAM-Parti with optimized ML alrothims for all treatments of the study
source("./Run_GLAM_Parti.R")

### Raname columns in model output
names(Daily_model_output) <- c('Treatment', 'Day', 'Leaf_Ear_mass', 'Stem_mass', 'Biomass', 'Yield', 'HI', 'RUE', 'No_exper', 'Repetition', 'Training_treatments', 'ML_model')
names(End_of_season_model_output) <- c('Treatment', 'Leaf_Ear_mass', 'Stem_mass', 'max_biom', 'max_yield', 'HI', 'RUE', 'Emer_Anth_days', 'Emer_Matur_days', 'No_exper', 'Repetition', 'Training_treatments', 'ML_model')


############### Evaluate model skill - GLAM-Parti was run with six treatments for RF training and six for model evaluation 
# Make single table of all crop treatments with observed and predicted end-of-season biomass, yield, days to anthesis and maturiy
Obs_Sim_end_of_season_output <- NULL
for (ieval in 1:nrow(End_of_season_crop_data)){
  itreatment <- End_of_season_crop_data$Treatment[ieval]
  
  # Observed and simulated end-of-season values for each treatment
  Obs_end_of_season_output_treat <- subset(End_of_season_crop_data, End_of_season_crop_data$Treatment == itreatment)
  Obs_end_of_season_output_treat$Method <- 'Observed'
  
  Sim_end_of_season_output_treat <- subset(End_of_season_model_output, End_of_season_model_output$Treatment==itreatment)
  Sim_end_of_season_output_treat$Method <- 'Predicted'
  Sim_end_of_season_output_treat$max_biom <- Sim_end_of_season_output_treat$max_biom/100
  Sim_end_of_season_output_treat$max_yield <- Sim_end_of_season_output_treat$max_yield/100
  
  if (is.element(itreatment, Training_treat) == TRUE){
    Period = 'Training'
  }else{
    Period = 'Evaluation'
  }
  
  # Merge observed and predicted columns for all treatments 
  common_col_names <- intersect(names(Obs_end_of_season_output_treat), names(Sim_end_of_season_output_treat))
  Obs_Sim_end_of_season_output <- rbind(Obs_Sim_end_of_season_output, data.frame(merge(Obs_end_of_season_output_treat, Sim_end_of_season_output_treat, by=common_col_names, all = TRUE), Period))
}

# Re-order treatments to bring training first
Obs_Sim_end_of_season_output$Treatment <- 
  factor(Obs_Sim_end_of_season_output$Treatment, levels = c(Training_treat, Eval_treat))

#### Biomass
# Keep only testing treatments for calculating evaluation metrics 
obs_pred_biom <- data.frame(Obs_Sim_end_of_season_output$max_biom[Obs_Sim_end_of_season_output$Period=='Evaluation'
                                                                  &Obs_Sim_end_of_season_output$Method=='Observed'], 
                            Obs_Sim_end_of_season_output$max_biom[Obs_Sim_end_of_season_output$Period=='Evaluation'
                                                                  &Obs_Sim_end_of_season_output$Method=='Predicted'])
names(obs_pred_biom) <- c('obs_biom', 'pred_biom')

# Calculate evaluation metrics for biomass
biom_metrics <- data.frame(rmse(obs_pred_biom$obs_biom, obs_pred_biom$pred_biom),
                           summary(lm(pred_biom~obs_biom, obs_pred_biom))$r.squared, 
                           tdStats(obs_pred_biom$pred_biom, obs_pred_biom$obs_biom,
                                   functions = c("mbe")))
names(biom_metrics) <- c('RMSE', 'Rsq', 'MBE')
biom_metrics <- round(biom_metrics, 2)

### Barplot
# Add metrics on top right corner and make plot
text = paste(paste("Rsq=", biom_metrics$Rsq, sep=''),
             paste("RMSE=", biom_metrics$RMSE, sep=''), 
             paste("MBE=", biom_metrics$MBE, sep=''), 
             sep = "\n")

grob <- grobTree(textGrob(text, x=0.8,  y=0.9, hjust=0,
                          gp=gpar(col="black", fontsize=9)))

Biom_barplot <- ggplot(data = Obs_Sim_end_of_season_output, mapping = aes(x=Treatment, y=max_biom, fill=Method)) +
  geom_bar(stat="identity", position = 'dodge')+  scale_fill_brewer(palette="Paired")+
  geom_vline(xintercept = no_experiments_training + 0.5, col='red', lwd=1.5) +
  labs(y=expression(paste("Biomass", ~ (t~ ha^-1), sep=""))) +
  geom_errorbar(aes(ymin = max_biom-sd_biom, ymax = max_biom+sd_biom), 
                data = Obs_Sim_end_of_season_output, width = 0.3, 
                position = position_dodge(width = 0.9)) +
  theme_minimal() +
  theme(legend.title = element_blank(), legend.text=element_text(size=14), axis.title.x=element_blank(), axis.title.y = element_text(size = 14)) +      
  annotation_custom(grob) 


##### Yield
# Keep only testing treatments for calculating evaluation metrics 
obs_pred_yield <- data.frame(Obs_Sim_end_of_season_output$max_yield[Obs_Sim_end_of_season_output$Period=='Evaluation'
                                                                    &Obs_Sim_end_of_season_output$Method=='Observed'], 
                             Obs_Sim_end_of_season_output$max_yield[Obs_Sim_end_of_season_output$Period=='Evaluation'
                                                                    &Obs_Sim_end_of_season_output$Method=='Predicted'])
names(obs_pred_yield) <- c('obs_yield', 'pred_yield')

# Calculate evaluation metrics for yield
yield_metrics <- data.frame(rmse(obs_pred_yield$obs_yield, obs_pred_yield$pred_yield),
                            summary(lm(pred_yield~obs_yield, obs_pred_yield))$r.squared,
                            tdStats(obs_pred_yield$pred_yield, obs_pred_yield$obs_yield,
                                    functions = c("mbe")))
names(yield_metrics) <- c('RMSE', 'Rsq', 'MBE')
yield_metrics <- round(yield_metrics, 2)

### Barpolt
# Add metrics on top right corner and make plot
text = paste(paste("Rsq=", yield_metrics$Rsq, sep=''),
             paste("RMSE=", yield_metrics$RMSE, sep=''), 
             paste("MBE=", yield_metrics$MBE, sep=''), 
             sep = "\n")

grob <- grobTree(textGrob(text, x=0.8,  y=0.9, hjust=0,
                          gp=gpar(col="black", fontsize=9)))

Yield_barplot <- ggplot(data = Obs_Sim_end_of_season_output, mapping = aes(x=Treatment, y=max_yield, fill=Method)) +
  geom_bar(stat="identity", position = 'dodge')+  scale_fill_brewer(palette="Paired")+
  geom_vline(xintercept = no_experiments_training + 0.5, col='red', lwd=1.5) +
  labs(y=expression(paste("Grain yield", ~ (t~ ha^-1), sep=""))) +
  geom_errorbar(aes(ymin = max_yield-sd_yield, ymax = max_yield+sd_yield), 
                data = Obs_Sim_end_of_season_output, width = 0.3, 
                position = position_dodge(width = 0.9)) +
  theme_minimal() +
  theme(legend.title = element_blank(), legend.text=element_text(size=14), axis.title.x=element_blank(), axis.title.y = element_text(size = 14)) +    
  annotation_custom(grob) 

#####Anthesis
# Keep only testing treatments for calculating evaluation metrics 
obs_pred_anth <- data.frame(Obs_Sim_end_of_season_output$Emer_Anth_days[Obs_Sim_end_of_season_output$Period=='Evaluation'
                                                                        &Obs_Sim_end_of_season_output$Method=='Observed'], 
                            Obs_Sim_end_of_season_output$Emer_Anth_days[Obs_Sim_end_of_season_output$Period=='Evaluation'
                                                                        &Obs_Sim_end_of_season_output$Method=='Predicted'])
names(obs_pred_anth) <- c('obs_anth', 'pred_anth')

# Calculate evaluation metrics for anthesis
anth_metrics <- data.frame(rmse(obs_pred_anth$obs_anth, obs_pred_anth$pred_anth),
                           summary(lm(pred_anth~obs_anth, obs_pred_anth))$r.squared,
                           tdStats(obs_pred_anth$pred_anth, obs_pred_anth$obs_anth,
                                   functions = c("mbe")))
names(anth_metrics) <- c('RMSE', 'Rsq', 'MBE')
anth_metrics <- round(anth_metrics, 2)

### Barpolt
# Add metrics on top right corner and make plot
text = paste(paste("Rsq=", anth_metrics$Rsq, sep=''),
             paste("RMSE=", anth_metrics$RMSE, sep=''), 
             paste("MBE=", anth_metrics$MBE, sep=''), 
             sep = "\n")

grob <- grobTree(textGrob(text, x=0.8,  y=0.9, hjust=0,
                          gp=gpar(col="black", fontsize=9)))

Anth_barplot <- ggplot(data = Obs_Sim_end_of_season_output, mapping = aes(x=Treatment, y=Emer_Anth_days, fill=Method)) +
  geom_bar(stat="identity", position = 'dodge')+  scale_fill_brewer(palette="Paired")+
  geom_vline(xintercept = no_experiments_training + 0.5, col='red', lwd=1.5) +
  ylab('Emergence to anthesis (days)') +
  annotation_custom(grob) +
  theme_minimal() +
  theme(legend.title = element_blank(), legend.text=element_text(size=14), axis.title = element_text(size = 14))

#####Maturity
# Keep only testing treatments for calculating evaluation metrics 
obs_pred_matur <- data.frame(Obs_Sim_end_of_season_output$Emer_Matur_days[Obs_Sim_end_of_season_output$Period=='Evaluation'
                                                                          &Obs_Sim_end_of_season_output$Method=='Observed'], 
                             Obs_Sim_end_of_season_output$Emer_Matur_days[Obs_Sim_end_of_season_output$Period=='Evaluation'
                                                                          &Obs_Sim_end_of_season_output$Method=='Predicted'])
names(obs_pred_matur) <- c('obs_matur', 'pred_matur')

# Calculate evaluation metrics for anthesis
matur_metrics <- data.frame(rmse(obs_pred_matur$obs_matur, obs_pred_matur$pred_matur),
                            summary(lm(pred_matur~obs_matur, obs_pred_matur))$r.squared,
                            tdStats(obs_pred_matur$pred_matur, obs_pred_matur$obs_matur,
                                    functions = c("mbe")))
names(matur_metrics) <- c('RMSE', 'Rsq', 'MBE')
matur_metrics <- round(matur_metrics, 2)

### Barpolt
# Add metrics on top right corner and make plot
text = paste(paste("Rsq=", matur_metrics$Rsq, sep=''),
             paste("RMSE=", matur_metrics$RMSE, sep=''), 
             paste("MBE=", matur_metrics$MBE, sep=''), 
             sep = "\n")

grob <- grobTree(textGrob(text, x=0.8,  y=0.9, hjust=0,
                          gp=gpar(col="black", fontsize=9)))

Matur_barplot <-ggplot(data = Obs_Sim_end_of_season_output, mapping = aes(x=Treatment, y=Emer_Matur_days, fill=Method)) +
  geom_bar(stat="identity", position = 'dodge')+  scale_fill_brewer(palette="Paired")+
  geom_vline(xintercept = no_experiments_training + 0.5, col='red', lwd=1.5) +
  annotation_custom(grob) +
  ylab('Emergence to maturity (days)') +
  theme_minimal() +
  theme(legend.title = element_blank(), legend.text=element_text(size=14), axis.title = element_text(size = 14))

####### Merge plots
GParti_eval_with_RF_fig <- ggarrange(Biom_barplot, Yield_barplot, Anth_barplot, Matur_barplot, 
                           ncol=2, nrow=2, common.legend = TRUE, legend = 'bottom', 
                           labels = c('A', 'B', 'C', 'D'), font.label = list(size = 14))

ggsave('./Results/Figures/Figure3.pdf', GParti_eval_with_RF_fig,  width = 10, height = 9, dpi = 300)
