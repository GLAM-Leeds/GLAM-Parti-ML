################## GLAM-Parti model
# Start with values of anthesis and maturity dates that are deliberately out of range (these will be updated later)
Anthesis_day = 0
Maturity_day = 366

######## Use ML algorithm to predict RUE
## First calculate accumulated SRAD, Tmean and thermal time
Input_weather_for_treat$SRAD_ACCU <- cumsum(Input_weather_for_treat$SRAD)
Input_weather_for_treat$TAV <- (Input_weather_for_treat$TMAX + Input_weather_for_treat$TMIN)/2
Input_weather_for_treat$TACCU <- cumsum(Input_weather_for_treat$TAV)

# Calculate VPD   
saturation_vapor_pressure_leaf_treat = (0.61078 * exp(17.27 * Input_weather_for_treat$TMAX/(Input_weather_for_treat$TMAX + 237.3)) + 
                                  0.61078 * exp(17.27 * Input_weather_for_treat$TMIN/(Input_weather_for_treat$TMIN + 237.3)))/2
  
saturation_vapor_pressure_dew_point_treat = 0.61078 * exp(17.27 * Input_weather_for_treat$TDEW/(Input_weather_for_treat$TDEW + 237.3))
Input_weather_for_treat$VPD = saturation_vapor_pressure_leaf_treat - saturation_vapor_pressure_dew_point_treat
    
# Start GLAM-Parti run
iday = 0
icounter = 0 

# Start empty vectors of state and rate variables
W_vec <- NULL
MP_vec <- NULL
MS_vec <- NULL
YIELD_vec <- NULL
RUE_vec <- NULL
HI_vec <- NULL

# Initialize variables (used in first day after emergence)
W = 0
HI = 0
dhdt = 0
MP_ratio_lag <- 0

while (iday < Maturity_day){
  iday = iday + 1
  
  # Import daily solar radiation
  Qo = Input_weather_for_treat$SRAD[Input_weather_for_treat$Day==iday]/2
  
  # Predict RUE with ML
  ML_table_for_RUE <- data.frame(Input_weather_for_treat[iday, c('SRAD', 'TMIN', 'TMAX', 'VPD')], MP_ratio_lag)
  RUE <- as.numeric(predict(ML_rue, ML_table_for_RUE))

  # Predict harvest index with ML
  if (Anthesis_day > 0){
    ML_table_for_HI <- data.frame(Input_weather_for_treat[iday, c('SRAD', 'TMIN', 'TMAX')], HI) 
    names(ML_table_for_HI) <- c('SRAD', 'TMIN', 'TMAX', 'HI_lag')
    dhdt <- as.numeric(predict(ML_dhdt, ML_table_for_HI))
    HI <- HI + dhdt
  }
     
  ### Run GLAM-Parti to estimate variables
  # Use SEMAC to predict MP (Mass of photosynthetic organs)
  MP = as.numeric(newton.raphson(func_test, 400, 1000)[1])
  
  # Update biomass growth (dW), total above-ground biomass (W), grain yield (YIELD), Mass of Stems (MS), stem:biomass ratio (MS_ratio), photosynthetic mass:biomass ratio (MP_ratio)
  dW = RUE*Qo*(1-exp(-kfac*SLA*10^(-4)*MP))
  W = W + dW
  MS = h*(MP^g)
  YIELD = HI*W
  MS_ratio = MS/W
  MP_ratio_lag = MP / W
  
  ### Update vectors
  W_vec = c(W_vec, W)
  MP_vec = c(MP_vec, MP)
  MS_vec = c(MS_vec, MS)
  YIELD_vec = c(YIELD_vec, YIELD)
  HI_vec <- c(HI_vec, HI)
  RUE_vec = c(RUE_vec, RUE)
     
  # Predict crop phenology with ML (iphen = 0 (pre-anthesis), iphen = 1 (anthesis-maturity), iphen = 2 (harvest time))
  ML_table_for_phenology <- data.frame(Input_weather_for_treat[iday, c('SRAD', 'TMIN', 'TMAX', 'SRAD_ACCU', 'TACCU')], MS_ratio) 
  phenol_day <- predict(ML_phen, ML_table_for_phenology) 
  
  if (phenol_day=='1' & icounter == 0){
    Anthesis_day = iday
    icounter = 1
  }else if (phenol_day=='2'){
    Maturity_day = iday
  }
}
