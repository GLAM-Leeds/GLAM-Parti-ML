########### Script to fit s-curves to observed biomass and yield values during the training period
#### We used the beta growth function from paper: A Flexible Sigmoid Function of Determinate Growth ...

# For every experiment, the goal is to find the day of maximum crop growth (tm_opt) based on the s-curve and the observed data
tm_opt_table <- NULL
biom_yield_opt_list <- list()

# Build biomass and yield s-curves and find optimal value for tm (tm_opt)
for (iscurv in 1:length(Training_treat)){
   itreat_scurv = Training_treat[iscurv]
   
   # For biomass s_curve
   biom_max = End_of_season_crop_data$max_biom[End_of_season_crop_data$Treat==itreat_scurv]
   te_biom = End_of_season_crop_data$Emer_Matur_days[End_of_season_crop_data$Treat==itreat_scurv]
   t_biom = c(1:te_biom)
  
   # For yield s_curve
   yield_max = End_of_season_crop_data$max_yield[End_of_season_crop_data$Treat==itreat_scurv]
   te_yield = End_of_season_crop_data$Emer_Matur_days[End_of_season_crop_data$Treat==itreat_scurv] - 
              End_of_season_crop_data$Emer_Anth_days[End_of_season_crop_data$Treat==itreat_scurv] 
   t_yield = c(1:te_yield)
    
   # Measurements for specific treatment
   Within_season_crop_data_treatment <- subset(Within_season_crop_data, Within_season_crop_data$Treatments == itreat_scurv)
   End_of_season_crop_data_treatment <- subset(End_of_season_crop_data, End_of_season_crop_data$Treat == itreat_scurv)
    
   ##### Iterate to find optimal tm for biomass and yield 
   # Start with very high RMSE 
   RMSE_opt_biom = 10^6
   RMSE_opt_yield = 10^6
   for (istep_scurv in seq(0.05, 0.95, by=0.05)){
  
      # biomass time series with s-curve
      tm_biom = istep_scurv*te_biom
      biom = biom_max*(1+(te_biom-t_biom)/(te_biom-tm_biom))*(t_biom/te_biom)^(te_biom/(te_biom-tm_biom))
      
      # Repeat biomass value at maturity enough times to match the last measurement date
      if (max(Within_season_crop_data_treatment$DAE) - length(biom) > 0){
          biom_f = c(biom, rep(tail(biom,1), (max(Within_season_crop_data_treatment$DAE) - length(biom))))
      }else{
       biom_f = biom
      }
      
      # Make biomass table with time series values and days after emergence
      biom_table <- data.frame(1:length(biom_f), biom_f)
      names(biom_table) <- c('DAE', 'Biomass_fitted')
      
      # Merge tables of observed and fitted biomass 
      Obs_fitted_biom_table <- merge(Within_season_crop_data_treatment, biom_table, by = 'DAE')
      
      # Find RMSE between biomass observations and simulations
      RMSE_istep_biom <- RMSE(Obs_fitted_biom_table$Biomass_fitted, Obs_fitted_biom_table$biom_season)
      
      # If RMSE lower than previous replace optimal tm with new value
      if (RMSE_istep_biom < RMSE_opt_biom) {
          RMSE_opt_biom = RMSE_istep_biom
          tm_opt_biom <- istep_scurv
          biom_f_opt <- biom
      }
      
      ##### Repeat the process of finding optimal tm for yield
      tm_yield = istep_scurv*te_yield
      yield = yield_max*(1+(te_yield-t_yield)/(te_yield-tm_yield))*(t_yield/te_yield)^(te_yield/(te_yield-tm_yield))
      
      # Add days from emergence to anthesis where grain yield is zero and repeat yield value at maturity enough times to match the last measurement date
      total_days_season <-c(1:End_of_season_crop_data_treatment$Emer_Matur_days)
      
      if (max(Within_season_crop_data_treatment$DAE) - length(total_days_season)>0){
          yield_f = c(rep(0, End_of_season_crop_data_treatment$Emer_Anth_days), yield, rep(tail(yield,1), max(Within_season_crop_data_treatment$DAE) - length(total_days_season)))
      }else{
          yield_f = c(rep(0, End_of_season_crop_data_treatment$Emer_Anth_days), yield)
      }
      
      # Make yield table with time series values and days after emergence
      yield_table <- data.frame(1:length(yield_f), yield_f)
      names(yield_table) <- c('DAE', 'Yield_fitted')
      
      # Merge tables of observed and fitted yield 
      Obs_fitted_yield_table <- merge(Within_season_crop_data_treatment, yield_table, by = 'DAE')
      RMSE_istep_yield <- RMSE(Obs_fitted_yield_table$Yield_fitted, Obs_fitted_yield_table$yield_season)
      
      if (RMSE_istep_yield < RMSE_opt_yield) {
          RMSE_opt_yield = RMSE_istep_yield
          tm_opt_yield <- istep_scurv
          yield_f_opt <- c(rep(0, End_of_season_crop_data_treatment$Emer_Anth_days), yield)
      }
      
      # Make plots for animation
#      nam <- paste("py", istep, sep = "")
#      In_season_table_treatment_for_plot <- In_season_table_treatment
#      In_season_table_treatment_for_plot$yield_season[is.na(In_season_table_treatment_for_plot$yield_season)] <- 0
      
#      Biom_yield_table <- merge(biom_table, yield_table, by = 'DAE')
#      Biom_yield_table_f <- melt(Biom_yield_table, "DAE")
      
#      assign(nam, ggplot() + geom_line(data=Biom_yield_table_f, aes(x=DAE, y = value, col=variable)) + 
#                scale_color_manual(labels = c("Biomass", "Grain yield"), values = c("black", "red"), guide = guide_legend(title = NULL)) +
#                geom_point(data = In_season_table_treatment_for_plot, mapping = aes(x = DAE, y = biom_season)) +
#                geom_point(data = In_season_table_treatment_for_plot, mapping = aes(x = DAE, y = yield_season), col='red') +
#                ggtitle(paste("tm=",  istep, '*te', sep='')) +
#                labs(x = "Day after emergence", y=expression(paste("Dry matter", ~ (t~ ha^-1), sep="")))+
#                theme_bw() +
 #               theme(plot.title = element_text(hjust = 0.5)))
   }
   
   tm_opt_table <- rbind(tm_opt_table, data.frame(tm_opt_biom, RMSE_opt_biom, tm_opt_yield, RMSE_opt_yield, itreat_scurv))

   # Make list with optimal biomass and yield time series
   name <- paste('treat', itreat_scurv, sep='')
   biom_yield_opt <- list(biom_f_opt, yield_f_opt)
   biom_yield_opt_list[[name]] <- biom_yield_opt
}

#library(animation)
#animation::saveGIF(
#   expr = {
#      plot(py0.05)
#      plot(py0.1)
#      plot(py0.15)
#      plot(py0.2)
#      plot(py0.25)
#      plot(py0.3)
#      plot(py0.35)
#      plot(py0.4)
#      plot(py0.45)
#      plot(py0.5)
#      plot(py0.55)
#      plot(py0.6)
#      plot(py0.65)
#      plot(py0.7)
#      plot(py0.75)
#      plot(py0.8)
#      plot(py0.85)
#      plot(py0.9)
#      plot(py0.95)
#   },
#   movie.name = "explicit_my3.gif"
#)


#ggplot() + geom_line(data=Biom_yield_table_f, aes(x=DAE, y = value, col=variable)) + 
#                   scale_color_manual(labels = c("Biomass", "Grain yield"), values = c("black", "red"), guide = guide_legend(title = NULL)) +
#                   geom_point(data = In_season_table_treatment_for_plot, mapping = aes(x = DAE, y = biom_season)) +
#                   geom_point(data = In_season_table_treatment_for_plot, mapping = aes(x = DAE, y = yield_season), col='red') +
#                   labs(x = "Days after emergence", y=expression(paste("Dry matter", ~ (t~ ha^-1), sep="")))+
#                   theme_bw() +
#                  theme(text = element_text(size=18), plot.title = element_text(hjust = 0.5))
